﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_LAB_PROYECTO_1_SmartPark
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //programa de smartPark
            string operador;
            int codigo, capacidad, tickets_creados = 0,  tickets_cerrados = 0, tiempo = 0;
            float dinero = 0;

            Console.WriteLine("Bienvenido a SmartPark");
            Console.WriteLine();

            Console.Write("Ingrese el nombre del operador: ");
            operador = Console.ReadLine();

            Console.WriteLine();
            Console.Write("Ingrese el código de turno (4 caracteres): ");
            codigo = int.Parse(Console.ReadLine());

            Console.WriteLine();
            Console.Write("Ingrese la capacidad del parqueo (Minimo 10 espacios): ");
            capacidad = int.Parse(Console.ReadLine());












        }
    }
}
