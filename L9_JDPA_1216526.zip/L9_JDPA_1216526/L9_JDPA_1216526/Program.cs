﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_JDPA_1216526
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Laboratorio 9 - Procedimientos");
            Console.WriteLine();

            //ejercicio 1
            string nombre;
            Console.WriteLine("Ejercicio 1:");
            Console.WriteLine();
            Console.Write("Ingrese su nombre: ");
            nombre = Console.ReadLine();

            SaludoPersonalizado(nombre);
            MostrarCurso();

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione cualquier tecla para continuar..");
            Console.ReadKey();
            Console.Clear();





            // ejercicio2
            Console.WriteLine("Ejercicio 2:");
            Console.WriteLine();

            int opcion;
            double lado, baseRect, alturaRect, baseTri, alturaTri;

            Console.WriteLine("1. Cuadrado");
            Console.WriteLine("2. Rectángulo");
            Console.WriteLine("3. Triángulo");
            Console.Write("Seleccione figura: ");

            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.WriteLine();
                    Console.Write("Ingrese lado: ");
                    lado = double.Parse(Console.ReadLine());
                    AreaCuadrado(lado);
                    break;

                case 2:
                    Console.WriteLine();
                    Console.Write("Ingrese base: ");
                    baseRect = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese altura: ");
                    alturaRect = double.Parse(Console.ReadLine());
                    AreaRectangulo(baseRect, alturaRect);
                    break;

                case 3:
                    Console.WriteLine();
                    Console.Write("Ingrese base: ");
                    baseTri = double.Parse(Console.ReadLine());
                    Console.Write("Ingrese altura: ");
                    alturaTri = double.Parse(Console.ReadLine());
                    AreaTriangulo(baseTri, alturaTri);
                    break;

                default:
                    Console.WriteLine("Opción no válida");
                    break;






            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione cualquier tecla para continuar..");
            Console.ReadKey();
            Console.Clear();



            //ejercicio 3

            Console.WriteLine("Ejercicio 3");
            do
            {
                Console.WriteLine();
                Console.WriteLine("1. Cuadrado");
                Console.WriteLine("2. Triángulo");
                Console.WriteLine("3. Línea");
                Console.WriteLine("4. Salir");
                Console.Write("Seleccione una opción: ");

                opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        Console.WriteLine();
                        Cuadrado();
                        break;

                    case 2:
                        Console.WriteLine();
                        Triangulo();
                        break;

                    case 3:
                        Console.WriteLine();
                        Linea();
                        break;

                    case 4:
                        Console.WriteLine();
                        Console.WriteLine("Saliendo...");
                        break;

                    default:
                        Console.WriteLine();
                        Console.WriteLine("Opción no válida");
                        break;
                }

            } while (opcion != 4);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione cualquier tecla para continuar..");
            Console.ReadKey();
            Console.Clear();




            // ejercicio 4
            Console.WriteLine("Ejercicio 4");
            Console.WriteLine();

            int aprobados = 0, reprobados = 0;
            double suma = 0;

            for (int i = 1; i <= 5; i++)
            {
                Console.Write("Ingrese nota " + i + ": ");
                double nota = double.Parse(Console.ReadLine());

                EvaluarNota(nota, ref aprobados, ref reprobados);
                suma += nota;
            }

            MostrarResumen(suma, aprobados, reprobados);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione cualquier tecla para continuar..");
            Console.ReadKey();
            Console.Clear();



            // ejercicio 5
            Console.WriteLine("Ejercicio 5");
            Console.WriteLine();

            int a, b;

            Console.Write("Ingrese el primer número: ");
            a = int.Parse(Console.ReadLine());

            Console.Write("Ingrese el segundo número: ");
            b = int.Parse(Console.ReadLine());

            Console.WriteLine("\nAntes: " + a + ", " + b);

            Intercambiar(ref a, ref b);

            Console.WriteLine("Después: " + a + ", " + b);
        }
        

         
        //ejercicio 1
        static void SaludoPersonalizado(string nombre)
        {
            Console.WriteLine();
            Console.WriteLine("Hola " + nombre + ", ¡bienvenido!");
        }

        static void MostrarCurso()
        {
            Console.WriteLine("Curso: Pensamiento computacional (Laboratorio)");
            Console.WriteLine();
            Console.WriteLine("Laboratorio: #9");
        }

        //ejercicio 2
        static void AreaCuadrado(double lado)
        {
            double area = lado * lado;
            Console.WriteLine();
            Console.WriteLine("Área del cuadrado: " + area);
        }

        static void AreaRectangulo(double baseR, double alturaR)
        {
            double area = baseR * alturaR;
            Console.WriteLine();
            Console.WriteLine("Área del rectángulo: " + area);
        }

        static void AreaTriangulo(double baseT, double alturaT)
        {
            double area = (baseT * alturaT) / 2;
            Console.WriteLine();
            Console.WriteLine("Área del triángulo: " + area);
        }



        // ejercicio 3
        static void Cuadrado()
        {
            Console.Write("Ingrese N: ");
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }

        static void Triangulo()
        {
            Console.Write("Ingrese N: ");
            int n = int.Parse(Console.ReadLine());

            for (int i = 1; i <= n; i++)
            {
                for (int j = 0; j < i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }

        static void Linea()
        {
            Console.Write("Ingrese N: ");
            int n = int.Parse(Console.ReadLine());

            for (int i = 0; i < n; i++)
            {
                Console.Write("*");
            }
            Console.WriteLine();
        }



        // ejercicio 4

        static void EvaluarNota(double nota, ref int aprobados, ref int reprobados)
        {
            if (nota >= 61)
            {
                Console.WriteLine("Aprobado");
                aprobados++;
            }
            else
            {
                Console.WriteLine("Reprobado");
                reprobados++;
            }

        }
        static void MostrarResumen(double suma, int aprobados, int reprobados)
        {
            double promedio = suma / 5;

            Console.WriteLine("RESUMEN");
            Console.WriteLine("Promedio: " + promedio);
            Console.WriteLine("Aprobados: " + aprobados);
            Console.WriteLine("Reprobados: " + reprobados);
        }



        //ejercicio 5

        static void Intercambiar(ref int x, ref int y)
        {
            int temp = x;
            x = y;
            y = temp;
        }
    }

}






