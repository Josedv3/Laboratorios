﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L14_JDPA_1216526
            {
    //ejercicio 1
    public class Libro
    {
        private string titulo;
        private string autor;
        private int anioPublicacion;
        private bool disponible;

        public Libro(string titulo, string autor, int anio, bool disponible)
        {
            this.titulo = titulo;
            this.autor = autor;
            this.anioPublicacion = anio;
            this.disponible = disponible;
        }

        public void MostrarInformacion()
        {
            string estado = "No disponible";
            if (disponible == true)
            {
                estado = "Disponible";
            }
            Console.WriteLine("Título: " + titulo);
            Console.WriteLine("Autor: " + autor);
            Console.WriteLine("Año: " + anioPublicacion);
            Console.WriteLine("Estado: " + estado);
        }

        public void PrestarLibro()
        {
            if (disponible == true)
            {
                disponible = false;
            }
        }

        public void DevolverLibro()
        {
            disponible = true;
        }
    }


    //ejercicio 2
    public class Mascota
    {
        private string nombre;
        private string especie;
        private int edad;
        private bool vacunado;

        public Mascota(string nombre, string especie, int edad, bool vacunado)
        {
            this.nombre = nombre;
            this.especie = especie;
            this.edad = edad;
            this.vacunado = vacunado;
        }

        public void MostrarInformacion()
        {
            Console.WriteLine("Nombre: " + nombre);
            Console.WriteLine("Especie: " + especie);
            Console.WriteLine("Edad: " + edad);
            Console.WriteLine("Vacunado: " + vacunado);
        }

        public void Vacunar()
        {
            vacunado = true;
        }

        public void CumplirAnios()
        {
            edad = edad + 1;
        }
    }





    //ejercicio 3
    public class Estudiante
    {
        private string nombre;
        private int edad;
        private string grado;
        private double[] notas;

        public Estudiante(string nombre, int edad, string grado, double[] notas)
        {
            this.nombre = nombre;
            this.edad = edad;
            this.grado = grado;
            this.notas = notas;
        }

        public double CalcularPromedio()
        {
            double suma = 0;
            for (int i = 0; i < notas.Length; i++)
            {
                suma = suma + notas[i];
            }
            return suma / notas.Length;
        }

        public void MostrarInformacion()
        {
            Console.WriteLine("Nombre: " + nombre);
            Console.WriteLine("Grado: " + grado);
            Console.WriteLine("Promedio: " + CalcularPromedio());
        }

        public void Aprobar()
        {
            if (CalcularPromedio() >= 61)
            {
                Console.WriteLine("Resultado: Aprobado");
            }
            else
            {
                Console.WriteLine("Resultado: Reprobado");
            }
        }
    }

    class Program
    {
        static void Main()
        {
            Console.WriteLine("EJERCICIO 1:"); 
            Console.WriteLine();

            Libro libro1 = new Libro("Don Quijote", "Cervantes", 1605, true);
            Libro libro2 = new Libro("El Principito", "Antoine", 1943, true);

            libro1.MostrarInformacion();
            Console.WriteLine();
            libro2.MostrarInformacion();
            Console.WriteLine();

            libro1.PrestarLibro();
            Console.WriteLine("Libro 1 prestado:");
            libro1.MostrarInformacion();
            Console.WriteLine();

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("presione una tecla para continuar");
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine(" EJERCICIO 2:");
            Console.WriteLine();

            Mascota mascota1 = new Mascota("Firulais", "Perro", 3, false);
            Mascota mascota2 = new Mascota("Luna", "Gato", 2, true);

            mascota1.MostrarInformacion();
            Console.WriteLine();
            mascota2.MostrarInformacion();
            Console.WriteLine();

            mascota1.Vacunar();
            mascota1.CumplirAnios();
            Console.WriteLine("Mascota 1 actualizada:");
            mascota1.MostrarInformacion();
            Console.WriteLine();

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("presione una tecla para continuar");
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("EJERCICIO 3:");
            Console.WriteLine();

            double[] notas1 = { 70, 80, 90 };
            double[] notas2 = { 40, 55, 60 };

            Estudiante est1 = new Estudiante("Carlos", 15, "Primero", notas1);
            Estudiante est2 = new Estudiante("Ana", 16, "Segundo", notas2);

            est1.MostrarInformacion();
            Console.WriteLine();
            est1.Aprobar();
            Console.WriteLine();

            est2.MostrarInformacion();
            Console.WriteLine();
            est2.Aprobar();
            Console.WriteLine();

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("presione una tecla para salir");
            Console.ReadKey();
            Console.Clear();
        }
    }
}