﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L15_JDPA_1216526
{

    class Program
    {
        static void Main()
        {
            Console.WriteLine("");
            Console.WriteLine("Ejercicio 1");

            // Error encontrado:
            // Tipo de error: sintaxis
            // Corrección realizada:
            // Se agregaron puntos y coma faltantes.
            // Explicación:
            // Las instrucciones deben finalizar con ;

            string nombre;
            int edad;

            Console.WriteLine("Ingrese su nombre:");
            nombre = Console.ReadLine();

            Console.WriteLine("Ingrese su edad:");
            edad = int.Parse(Console.ReadLine());

            Console.WriteLine("Hola " + nombre);
            Console.WriteLine("Tienes " + edad + " años");

            if (edad >= 18)
            {
                Console.WriteLine("Eres mayor de edad");
            }
            else
            {
                Console.WriteLine("Eres menor de edad");
            }

            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadKey();

            Console.Clear();

            Console.WriteLine();
            Console.WriteLine("Ejercicio 2");

            double nota1;
            double nota2;
            double nota3;
            double promedio;

            Console.WriteLine("Ingrese la primera nota:");
            nota1 = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la segunda nota:");
            nota2 = double.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese la tercera nota:");
            nota3 = double.Parse(Console.ReadLine());

            // Error encontrado:
            // Tipo de error: lógico
            // Corrección realizada:
            // Se agregaron paréntesis en el promedio.
            // Explicación:
            // Antes solo se dividía la tercera nota entre 3.

            promedio = (nota1 + nota2 + nota3) / 3;

            Console.WriteLine("El promedio es: " + promedio);

            // Error encontrado:
            // Tipo de error: lógico
            // Corrección realizada:
            // Se cambió > por >=
            // Explicación:
            // Un estudiante con 61 también aprueba.

            if (promedio >= 61)
            {
                Console.WriteLine("El estudiante aprobó");
            }
            else
            {
                Console.WriteLine("El estudiante reprobó");
            }

            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadKey();

            Console.Clear();

            Console.WriteLine();
            Console.WriteLine("Ejercicio 3");

            int[] numeros = new int[5];
            int suma = 0;

            // Error encontrado:
            // Tipo de error: ejecución
            // Corrección realizada:
            // Se cambió i <= 5 por i < 5
            // Explicación:
            // El arreglo tiene posiciones de 0 a 4.

            for (int i = 0; i < 5; i++)
            {
                bool valido = false;

                while (!valido)
                {
                    Console.WriteLine("Ingrese un número:");

                    if (int.TryParse(Console.ReadLine(), out numeros[i]))
                    {
                        valido = true;
                    }
                    else
                    {
                        Console.WriteLine("Entrada inválida. Intente nuevamente.");
                    }
                }
            }

            for (int i = 0; i < 5; i++)
            {
                suma = suma + numeros[i];
            }

            Console.WriteLine("La suma total es: " + suma);

            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadKey();

            Console.Clear();

            Console.WriteLine();
            Console.WriteLine("Ejercicio 4");

            double baseRectangulo = 0;
            double alturaRectangulo = 0;

            bool baseValida = false;

            while (!baseValida)
            {
                Console.WriteLine("Ingrese la base del rectángulo:");

                if (double.TryParse(Console.ReadLine(), out baseRectangulo))
                {
                    if (baseRectangulo > 0)
                    {
                        baseValida = true;
                    }
                    else
                    {
                        Console.WriteLine("La base debe ser mayor que cero.");
                    }
                }
                else
                {
                    Console.WriteLine("Entrada inválida.");
                }
            }

            bool alturaValida = false;

            while (!alturaValida)
            {
                Console.WriteLine("Ingrese la altura del rectángulo:");

                if (double.TryParse(Console.ReadLine(), out alturaRectangulo))
                {
                    if (alturaRectangulo > 0)
                    {
                        alturaValida = true;
                    }
                    else
                    {
                        Console.WriteLine("La altura debe ser mayor que cero.");
                    }
                }
                else
                {
                    Console.WriteLine("Entrada inválida.");
                }
            }

            double area = CalcularArea(baseRectangulo, alturaRectangulo);

            Console.WriteLine("El área es: " + area);

            // Error encontrado:
            // Tipo de error: lógico
            // Corrección realizada:
            // Se cambió > por >=
            // Explicación:
            // Un área igual a 100 debe considerarse grande.

            if (area >= 100)
            {
                Console.WriteLine("El área es grande");
            }
            else
            {
                Console.WriteLine("El área es pequeña");
            }

            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadKey();

            Console.Clear();

            Console.WriteLine();
            Console.WriteLine("Ejercicio 5");

            int[] edades = new int[5];
            int sumaEdades = 0;
            int mayores = 0;
            double promedioEdades;

            // Análisis de la solución generada por IA:
            // Error 1:
            // El ciclo iniciaba en 1 y terminaba en 5.
            // Error 2:
            // El arreglo intentaba acceder a posiciones inexistentes.
            // Error 3:
            // El promedio utilizaba división entera.
            // Limitación encontrada:
            // No validaba texto ni edades negativas.
            // Importancia de la validación humana:
            // La IA puede generar código incorrecto o incompleto.

            for (int i = 0; i < 5; i++)
            {
                bool edadValida = false;

                while (!edadValida)
                {
                    Console.WriteLine("Ingrese la edad de la persona " + (i + 1) + ":");

                    if (int.TryParse(Console.ReadLine(), out edades[i]))
                    {
                        if (edades[i] >= 0)
                        {
                            edadValida = true;
                        }
                        else
                        {
                            Console.WriteLine("La edad no puede ser negativa.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Entrada inválida.");
                    }
                }

                sumaEdades = sumaEdades + edades[i];

                // Error encontrado:
                // Tipo de error: lógico
                // Corrección realizada:
                // Se cambió > por >=
                // Explicación:
                // Una persona con 18 años ya es mayor de edad.

                if (edades[i] >= 18)
                {
                    mayores++;
                }
            }

            // Error encontrado:
            // Tipo de error: lógico
            // Corrección realizada:
            // Se convirtió la división a decimal.
            // Explicación:
            // El promedio puede mostrar decimales correctamente.

            promedioEdades = (double)sumaEdades / 5;

            Console.WriteLine("El promedio de edades es: " + promedioEdades);
            Console.WriteLine("Cantidad de mayores de edad: " + mayores);

            // ¿Por qué una solución generada por Inteligencia Artificial debe ser revisada,
            // probada y validada por una persona antes de considerarse correcta?
            //
            // Porque la Inteligencia Artificial puede generar errores
            // de sintaxis, lógica o ejecución.
            // Aunque el código parezca correcto, puede fallar
            // o producir resultados incorrectos.
            // Por eso el programador debe revisar y validar
            // cada solución antes de utilizarla.

            Console.WriteLine(45
                );
            Console.WriteLine();

            Console.WriteLine("Presione una tecla para finalizar");
            Console.ReadKey();
        }

        static double CalcularArea(double baseRectangulo, double alturaRectangulo)
        {
            // Error encontrado:
            // Tipo de error: lógico
            // Corrección realizada:
            // Se cambió suma por multiplicación.
            // Explicación:
            // El área de un rectángulo es base * altura.

            double resultado;

            resultado = baseRectangulo * alturaRectangulo;

            return resultado;
        }
    }
}

