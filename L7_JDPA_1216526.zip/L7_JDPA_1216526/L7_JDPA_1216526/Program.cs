﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace L7_JDPA_1216526
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Entrada
            Console.Write("Ingrese su nombre: ");
            string nombre = Console.ReadLine();
            // Proceso + Salida
            Console.WriteLine("Hola, " + nombre + ". ¡Bienvenido/a al Laboratorio 7");



            //ejercicio 1:
            Console.WriteLine();
            Console.WriteLine("Ejercicio 1:");
            Console.WriteLine();

            int cantidad, contador, suma;
            float promedio;

            suma = 0;
            contador = 1;

            Console.Write("Ingrese cuantos numeros desea sumar: ");
            cantidad = int.Parse(Console.ReadLine());

            //mientras el contador sea menor o igual a la cantidad de numeros que se desean sumar,
            //el programa seguira pidiendo numeros y sumandolos

            while (cantidad <= 0)
            {
                Console.WriteLine();
                Console.WriteLine("La cantidad debe ser un numero positivo. Por favor, ingrese nuevamente.");
                Console.Write("Ingrese cuantos numeros desea sumar: ");
                cantidad = int.Parse(Console.ReadLine());
            } 

            while (contador <= cantidad) {

                suma = suma + contador;
                contador++;
            }

            Console.WriteLine();
            Console.WriteLine("La suma de los numeros es: " + suma);

            promedio = suma / cantidad;
            Console.WriteLine();
            Console.WriteLine("El promedio es: " + promedio);

            //esto ayuda a que el programa no se cierre inmediatamente despues de mostrar resultados,
            // y poder pasar a el siguiente programa despues de presionar una tecla

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("PRESIONE UNA TECLA PARA CONTINUAR");
            Console.ReadKey();
            Console.Clear();




            //ejercicio 2:
            Console.WriteLine("Ejercicio 2:");
            Console.WriteLine();
            int opcion;
            double celsius, fahrenheit;
            Console.WriteLine("MENU DE OPCIONES");
            Console.WriteLine("1. Convertir Celsius a Fahrenheit");
            Console.WriteLine("2. Convertir Fahrenheit a Celsius");
            Console.WriteLine("3. Convertir Kilómetros a Millas");
            Console.WriteLine("4. Salir");

            //do while ayuda a que mientras que el usuario no elija la opcion 4 el programa se siga ejecutando

            do
            {
                Console.WriteLine();
                Console.Write("Que opcion desea elegir: ");

                opcion = int.Parse(Console.ReadLine());


                switch (opcion)
                {
                    case 1:
                        Console.WriteLine();
                        Console.Write("Ingrese la temperatura en Celsius: ");
                        celsius = double.Parse(Console.ReadLine());
                        fahrenheit = (celsius * 9 / 5) + 32;
                        Console.WriteLine("La temperatura en Fahrenheit es: " + fahrenheit);
                        break;

                    case 2:
                        Console.WriteLine();
                        Console.Write("Ingrese la temperatura en Fahrenheit: ");
                        fahrenheit = double.Parse(Console.ReadLine());
                        celsius = (fahrenheit - 32) * 5 / 9;
                        Console.WriteLine("La temperatura en Celsius es: " + celsius);
                        break;

                    case 3:
                        Console.WriteLine();
                        Console.Write("Ingrese la distancia en Kilómetros: ");
                        double kilometros = double.Parse(Console.ReadLine());
                        double millas = kilometros * 0.621371;
                        Console.WriteLine("La distancia en Millas es: " + millas);
                        break;

                    case 4:
                        Console.WriteLine();
                        Console.WriteLine("Saliendo del programa...");
                        break;

                    default:
                        Console.WriteLine();
                        Console.WriteLine("Opción no válida. Por favor, elija una opción del menú.");
                        break;
                }


            } while (opcion != 4);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("PRESIONE UNA TECLA PARA CONTINUAR");
            Console.ReadKey();
            Console.Clear();


            //ejercicio 3:
            Console.WriteLine("Ejercicio 3:");
            

            Random random = new Random();
            int numero_x = random.Next(1,101), numero_intentos, numero_usuario;
            
            numero_intentos = 0;


            do
            {
                Console.WriteLine();
                Console.Write("Ingrese un numero entre 1 a 100: ");
                numero_usuario = int.Parse(Console.ReadLine());

                if (numero_usuario < 1 || numero_usuario > 100)
                {
                    Console.WriteLine();
                    Console.WriteLine("El numero debe estar entre 1 y 100. Por favor, ingrese nuevamente.");
                    numero_intentos--;
                }

                if (numero_usuario < numero_x)
                {
                    Console.WriteLine("El numero es mas alto");
                }
                if (numero_usuario > numero_x)
                {
                    Console.WriteLine("El numero es mas bajo");
                }

                numero_intentos++;

            } while (numero_usuario != numero_x);


            Console.WriteLine();
            Console.WriteLine("¡Felicidades! Has adivinado el numero en " + numero_intentos + " intentos");


            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("PRESIONE UNA TECLA PARA CONTINUAR");
            Console.ReadKey();
            Console.Clear();



            // ejercicio 4:
            Console.WriteLine("Ejercicio 4:");
          
            int pin, intentos;

            intentos = 0;

            // el do while hace que mientras el pin sea diferente a 1234 repita la accion de pedir el pin

            do { 
                Console.WriteLine();
                Console.Write("Ingrese su PIN: ");
                pin = int.Parse(Console.ReadLine());

                if (pin != 1234)
                {
                    intentos++;
                    Console.WriteLine("PIN incorrecto. Intento " + intentos + " de 3.");
                }
                if (intentos >= 3)
                {
                    Console.WriteLine("Cuenta bloqueada");

                }
            } while (pin != 1234 && intentos < 3);

            if (pin == 1234)
            {
                Console.WriteLine("Acceso concedido");
            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("PRESIONE UNA TECLA PARA SALIR");
            Console.ReadKey();


        }
    }
}
