﻿using System;

namespace L13_JDPA_1216526
{
    class Program
    {
        static void Main()
        {
            //ejercicio 1:
            Console.WriteLine("Ejercicio 1:");
            Console.WriteLine();

            Persona p1 = new Persona();

            p1.nombre = "David";
            p1.edad = 18;
            p1.altura = 1.82;
            p1.estudiante = true;

            Console.WriteLine("PERSONA:");
            Console.WriteLine("Nombre: " + p1.nombre);
            Console.WriteLine("Edad: " + p1.edad);
            Console.WriteLine("Altura: " + p1.altura);
            Console.WriteLine("Estudiante: " + p1.estudiante);


            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadKey();
            Console.Clear();


            //ejercicio 2:
            Console.WriteLine("Ejercicio 2:");
           

            Vehiculo v1 = new Vehiculo();

            v1.marca = "hyundai";
            v1.modelo = "i30";
            v1.año = 2020;
            v1.color = "Rojo";
            v1.placa = "P123ABC";

            Console.WriteLine();
            Console.WriteLine("VEHICULO:");
            Console.WriteLine("Marca: " + v1.marca);
            Console.WriteLine("Modelo: " + v1.modelo);
            Console.WriteLine("Año: " + v1.año);
            Console.WriteLine("Color: " + v1.color);
            Console.WriteLine("Placa: " + v1.placa);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadKey();
            Console.Clear();



            //ejercicio 3: 
            Console.WriteLine("Ejercicio 3:");
            

            Producto prod1 = new Producto();
            Producto prod2 = new Producto();

            prod1.codigo = "001";
            prod1.nombre = "Laptop";
            prod1.precio = 5000;
            prod1.stock = 10;
            prod1.disponible = true;

            prod2.codigo = "002";
            prod2.nombre = "Mouse";
            prod2.precio = 50;
            prod2.stock = 25;
            prod2.disponible = true;

            Console.WriteLine();
            Console.WriteLine(" PRODUCTO 1:");
            Console.WriteLine("Codigo: " + prod1.codigo);
            Console.WriteLine("Nombre: " + prod1.nombre);
            Console.WriteLine("Precio: " + prod1.precio);
            Console.WriteLine("Stock: " + prod1.stock);
            Console.WriteLine("Disponible: " + prod1.disponible);

            Console.WriteLine();
            Console.WriteLine(" PRODUCTO 2 ");
            Console.WriteLine("Codigo: " + prod2.codigo);
            Console.WriteLine("Nombre: " + prod2.nombre);
            Console.WriteLine("Precio: " + prod2.precio);
            Console.WriteLine("Stock: " + prod2.stock);
            Console.WriteLine("Disponible: " + prod2.disponible);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione una tecla para continuar");
            Console.ReadKey();
            Console.Clear();



            //ejericio 4: 
            Console.WriteLine("Ejercicio 4:");
            

            Mascota m1 = new Mascota();

            m1.nombre = "Toby";
            m1.especie = "Perro";
            m1.edad = 7;
            m1.peso = 12.5;
            m1.vacunado = true;

            Console.WriteLine();
            Console.WriteLine(" MASCOTA:");
            Console.WriteLine("Nombre: " + m1.nombre);
            Console.WriteLine("Especie: " + m1.especie);
            Console.WriteLine("Edad: " + m1.edad);
            Console.WriteLine("Peso: " + m1.peso);
            Console.WriteLine("Vacunado: " + m1.vacunado);


            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione una tecla para salir");
            Console.ReadKey();
            Console.Clear();


        }
    }
    //ejercicio1: 
    class Persona
    {
        public string nombre;
        public int edad;
        public double altura;
        public bool estudiante;
    }



    //ejercicio2:
    class Vehiculo
    {
        public string marca;
        public string modelo;
        public int año;
        public string color;
        public string placa;
    }



    //ejercicio3:
    class Producto
    {
        public string codigo;
        public string nombre;
        public double precio;
        public int stock;
        public bool disponible;
    }


    //ejercici4: 

    class Mascota
    {
        public string nombre;
        public string especie;
        public int edad;
        public double peso;
        public bool vacunado;
    }

}