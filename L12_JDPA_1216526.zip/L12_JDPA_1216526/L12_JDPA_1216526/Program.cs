﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12_JDPA_1216526
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // Entrada de usuario
            Console.Write("¿Cómo te llamas? ");
            string nombre = Console.ReadLine();
            // Salida de datos
            Console.WriteLine("Hola, " + nombre + " ¡Bienvenido a C#!");
            int[,] matriz = new int[4, 4];
            int fila, col;

           
            //ejercicio 1
            llenarMatriz(matriz);

            Console.WriteLine();


            Console.Write("Ingrese el numero de fila (0-3): ");
            fila = int.Parse(Console.ReadLine());

            Console.WriteLine();

            Console.WriteLine("La suma de la fila es: " + sumaFila(matriz, fila));

            Console.WriteLine();

            Console.WriteLine();

            Console.Write("Ingrese el numero de columna (0-3): ");
            col = int.Parse(Console.ReadLine());

            Console.WriteLine();

            
            Console.WriteLine("La suma de la columna es: " + sumaColumna(matriz, col));

            Console.WriteLine();

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione una tecla para continuar...");
            Console.ReadKey();
            Console.Clear();





            //ejercicio 2
            Console.WriteLine("Ejercicio 2:");
            Console.WriteLine();


            float[,] matriz2 = new float[3, 5];
            float mayor;

           
            cargarMatriz(matriz2);

            Console.WriteLine();

            
            mayor = mayorMatriz(matriz2);

            Console.WriteLine();

            
            Console.WriteLine("El valor mayor de la matriz es: " + mayor);

            Console.WriteLine();

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione una tecla para continuar...");
            Console.ReadKey();
            Console.Clear();




            //ejercicio 3

            int[,] A = new int[3, 2], B = new int[2, 3], R = new int[3, 3];
        int i, j;

        Console.WriteLine("Llenando matriz A (3x2):");
        cargarMatrizA(A);

        Console.WriteLine();

        Console.WriteLine("Llenando matriz B (2x3):");
        cargarMatrizB(B);

        Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione una tecla para continuar...");
            Console.ReadKey();
            Console.Clear();




            //ejercicio 4
            int[,] matriz4 = new int[5, 5];
            int suma1, suma2;

            
            llenar(matriz4);

            Console.WriteLine();

            
            suma1 = sumaDiagonalPrincipal(matriz4);
            suma2 = sumaDiagonalSecundaria(matriz4);

            Console.WriteLine();

            
            Console.WriteLine("Suma diagonal principal: " + suma1);

            Console.WriteLine();

            Console.WriteLine("Suma diagonal secundaria: " + suma2);

            Console.WriteLine();

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione una tecla para salir");
            Console.ReadKey();
        }
        

       //ejercicio 1
        static void llenarMatriz(int[,] m)
        {
            int i, j;

            for (i = 0; i < 4; i++)
            {
                for (j = 0; j < 4; j++)
                {
                    Console.Write("Ingrese valor [" + i + "][" + j + "]: ");
                    m[i, j] = int.Parse(Console.ReadLine());
                }
            }
        }

        //ejercicio 1
        static int sumaFila(int[,] m, int fila)
        {
            int j, suma = 0;

            for (j = 0; j < 4; j++)
            {
                suma = suma + m[fila, j];
            }

            return suma;
        }

        //ejercicio 1
        static int sumaColumna(int[,] m, int col)
        {
            int i, suma = 0;

            for (i = 0; i < 4; i++)
            {
                suma = suma + m[i, col];
            }

            return suma;
        }




        //ejercicio 2
        static void cargarMatriz(float[,] m)
        {
            int i, j;

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    Console.Write("Ingrese valor [" + i + "][" + j + "]: ");
                    m[i, j] = float.Parse(Console.ReadLine());
                }
            }
        }

        //ejercicio 2
        static float mayorMatriz(float[,] m)
        {
            int i, j;
            float mayor = m[0, 0];

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    if (m[i, j] > mayor)
                    {
                        mayor = m[i, j];
                    }
                }
            }

            return mayor;
        }








        //ejercicio 3
        static void cargarMatrizA(int[,] m)
        {
            int i3, j3;

            for (i3 = 0; i3 < 3; i3++)
            {
                for (j3 = 0; j3 < 2; j3++)
                {
                    Console.Write("Ingrese A[" + i3 + "][" + j3 + "]: ");
                    m[i3, j3] = int.Parse(Console.ReadLine());
                }
            }
        }

        // ejercicio 3
        static void cargarMatrizB(int[,] m)
        {
            int i3, j3;

            for (i3 = 0; i3 < 2; i3++)
            {
                for (j3 = 0; j3 < 3; j3++)
                {
                    Console.Write("Ingrese B[" + i3 + "][" + j3 + "]: ");
                    m[i3, j3] = int.Parse(Console.ReadLine());
                }
            }
        }

        //ejercicio 3
        static void multiplicar(int[,] A, int[,] B, int[,] R)
        {
            int i3, j3, k;

            for (i3 = 0; i3 < 3; i3++)
            {
                for (j3 = 0; j3 < 3; j3++)
                {
                    R[i3, j3] = 0;

                    for (k = 0; k < 2; k++)
                    {
                        R[i3, j3] = R[i3, j3] + A[i3, k] * B[k, j3];
                    }
                }
            }
        }










        //ejercicio 4
        static void llenar(int[,] m)
        {
            int a, b;

            for (a = 0; a < 5; a++)
            {
                for (b = 0; b < 5; b++)
                {
                    Console.Write("Ingrese valor [" + a + "][" + b + "]: ");
                    m[a, b] = int.Parse(Console.ReadLine());
                }
            }
        }

        //ejercicio 4
        static int sumaDiagonalPrincipal(int[,] m)
        {
            int c, suma = 0;

            for (c = 0; c < 5; c++)
            {
                suma = suma + m[c, c];
            }

            return suma;
        }

        //ejercicio 4
        static int sumaDiagonalSecundaria(int[,] m)
        {
            int d, suma = 0;

            for (d = 0; d < 5; d++)
            {
                suma = suma + m[d, 4 - d];
            }

            return suma;
        }
    }
    }


