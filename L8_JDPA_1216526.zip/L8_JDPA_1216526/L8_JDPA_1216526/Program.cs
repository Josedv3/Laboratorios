﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L8_JDPA_1216526
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Entrada de usuario
            Console.Write("¿Cómo te llamas? ");
            string nombre = Console.ReadLine();
            // Salida de datos

            //EJERCICIO #1
            Console.WriteLine();
            Console.WriteLine("Hola, " + nombre + " ¡Bienvenido a C#!");

            int nota, cantidadAprobados = 0, CantidadReprobados = 0, suma = 0;
            double promedio = 0;
            Console.WriteLine("Ejercicio#1");
            Console.WriteLine();
            for (int i = 1; i <= 10; i++)
            {
                Console.Write("Ingrese la nota " + i + ": ");
                nota = int.Parse(Console.ReadLine());
                Console.WriteLine();
                if (nota >= 65)
                {
                    cantidadAprobados++;
                }
                else
                {
                    CantidadReprobados++;
                }
                suma = suma + nota;
            }
            promedio = suma / 10;
            Console.WriteLine();
            Console.WriteLine("Su promedio fue de: " + promedio);
            Console.WriteLine();
            Console.WriteLine("Los aprobados fueron: " + cantidadAprobados);
            Console.WriteLine();
            Console.WriteLine("Los reprobados fueron: " + CantidadReprobados);
            Console.WriteLine();

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("PRESIONE UNA TECLA PARA CONTINUAR...");
            Console.ReadKey();
            Console.Clear();


            // EJERCICIO #2
            Console.WriteLine("Ejercicio#2");
            Console.WriteLine();

            int numero, i2, sumatoria, pares, impares;

            sumatoria = 0;
            pares = 0;
            impares = 0;
            i2 = 1;

            Console.WriteLine("Escriba un numero: ");
            numero = int.Parse(Console.ReadLine());

            for (i2 = 1; i2 <= numero; i2++)
            {

                sumatoria = sumatoria + i2;

                if (i2 % 2 == 0)
                {
                    pares++;
                }
                else
                {
                    impares++;
                }


            }

            Console.WriteLine();
            Console.WriteLine("La suma es: " + sumatoria);
            Console.WriteLine();
            Console.WriteLine("La cantidad de numeros pares es: " + pares);
            Console.WriteLine();
            Console.WriteLine("La cantidad de numeros impares es: " + impares);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("PRESIONE UNA TECLA PARA CONTINUAR...");
            Console.ReadKey();
            Console.Clear();



            // EJERCICIO #3
            Console.WriteLine("Ejercicio#3");
            Console.WriteLine();

            int opcion, MontoCompra, TotalVentas, Clientes;

            Console.WriteLine("MENU DE OPCIONES");
            Console.WriteLine("1. Registrar compra");
            Console.WriteLine("2. Mostrar total de ventas");
            Console.WriteLine("3. Mostrar cantidad de clientes atendidos");
            Console.WriteLine("4. Salir");

            TotalVentas = 0;
            Clientes = 0;

            do
            {
                Console.WriteLine();
                Console.Write("Que opcion desea elegir: ");

                opcion = int.Parse(Console.ReadLine());


                switch (opcion)
                {
                    case 1:
                        Console.WriteLine();
                        Console.Write("Ingrese el monto de compra: Q");
                        MontoCompra = int.Parse(Console.ReadLine());

                        TotalVentas = TotalVentas + MontoCompra;
                        Clientes++;

                        break;

                    case 2:
                        Console.WriteLine();
                        Console.Write("Total de ventas acumuladas del dia: Q" + TotalVentas);
                        Console.WriteLine();
                        break;


                    case 3:
                        Console.WriteLine();
                        Console.Write("Clientes atendidos del dia: " + Clientes);
                        Console.WriteLine();
                        break;



                    case 4:
                        Console.WriteLine();
                        Console.WriteLine("Saliendo del programa...");
                        break;


                    default:
                        Console.WriteLine();
                        Console.WriteLine("Ingrese una opcion valida");
                        break;

                }


            } while (opcion != 4);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("PRESIONE UNA TECLA PARA CONTINUAR...");
            Console.ReadKey();
            Console.Clear();


            // EJERCICIO #4
            Console.WriteLine("Ejercicio 4:");
            Console.WriteLine();

            int numero_1, positivos, negativos, suma_total;

            positivos = 0;
            negativos = 0;  
            suma_total= 0;
          
            do
            {
                Console.Write("Ingrese un numero: ");
                numero_1 = int.Parse(Console.ReadLine());

                suma_total = suma_total + numero_1;

                if (numero_1 > 0)
                {
                    positivos++;
                }
                else if (numero_1 < 0)
                {
                    negativos++;
                }

            } while (numero_1 != 0);

            Console.WriteLine();
            Console.WriteLine("La cantidad de numeros positivos es: " + positivos);

            Console.WriteLine();
            Console.WriteLine("La cantidad de numeros negativos es: " + negativos);
            
            Console.WriteLine();
            Console.WriteLine("La suma total es: " + suma_total);



            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("PRESIONE UNA TECLA PARA CONTINUAR...");
            Console.ReadKey();
            Console.Clear();



            //EJERCICIO #5
            Console.WriteLine("Ejercicio 5:");
            Console.WriteLine();

            int N, cont, j;

            Console.Write("Ingrese un numero N: ");
            N = int.Parse(Console.ReadLine());

            for (cont = 1; cont <= N; cont++)
            {
                for (j = 1; j <= cont; j++)
                {
                    Console.Write(j);
                }
                Console.WriteLine();
            }


            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("PRESIONE UNA TECLA PARA SALIR...");
            Console.ReadKey();


        }

    }
    }
