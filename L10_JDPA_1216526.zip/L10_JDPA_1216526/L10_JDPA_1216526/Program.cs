﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L10_JDPA_1216526
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("¿Cómo te llamas? ");
            string nombre = Console.ReadLine();
            // Salida de datos
            Console.WriteLine("Hola, " + nombre + " ¡Bienvenido a C#!");


            //ejercicio 1 
            Console.WriteLine("Ejercicio 1:");
            Console.WriteLine();

            int numero, resultado;

            Console.Write("Ingrese un número: ");
            numero = int.Parse(Console.ReadLine());

            resultado = SumarDigitos(numero);

            Console.WriteLine();
            Console.WriteLine("La suma de los dígitos es: " + resultado);

            Console.WriteLine() ;
            Console.WriteLine();
            Console.WriteLine("Presione cualquier tecla para continuar...");
            Console.ReadKey();
            Console.Clear();


            //ejercicio 2
            Console.WriteLine("Ejercicio 2:");
            Console.WriteLine();


            int num;
            string mensaje;

            Console.Write("Ingrese un número: ");
            num = int.Parse(Console.ReadLine());

            mensaje = ElevarAlCuadrado(ref num);

            Console.WriteLine(mensaje);
            Console.WriteLine();
            Console.WriteLine("Valor final de N: " + num);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione cualquier tecla para continuar...");
            Console.ReadKey();
            Console.Clear();



            //ejercicio 3 
            Console.WriteLine("Ejercicio 3:");
            Console.WriteLine();

            double precio, descuento, montoDescuento;

            Console.Write("Ingrese el precio: ");
            precio = double.Parse(Console.ReadLine());

            Console.Write("Ingrese el descuento (ej. 0.25): ");
            descuento = double.Parse(Console.ReadLine());

            montoDescuento = AplicarDescuento(descuento, ref precio);

            Console.WriteLine();
            Console.WriteLine("Precio final: " + precio);
            Console.WriteLine();
            Console.WriteLine("Descuento: " + montoDescuento);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione cualquier tecla para continuar...");
            Console.ReadKey();
            Console.Clear();




            //ejercicio 4

            int energiaJugador, energiaRestante, energiaActual;
            string estado, rendimiento;

            Console.Write("Ingrese la energía inicial (0 - 20): ");
            energiaJugador = int.Parse(Console.ReadLine());

            Console.WriteLine();
            energiaRestante = ConsumirEnergia(ref energiaJugador);
            Console.WriteLine("Energía después de consumir: " + energiaRestante);

            Console.WriteLine();
            energiaActual = RecargarEnergia(ref energiaJugador);
            Console.WriteLine("Energía después de recargar: " + energiaActual);

            Console.WriteLine();
            estado = ObtenerEstado(energiaJugador);
            Console.WriteLine("Estado: " + estado);

            Console.WriteLine();
            rendimiento = CalcularRendimiento(energiaJugador);
            Console.WriteLine("Rendimiento: " + rendimiento);
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Presione cualquier tecla para salir");
            Console.ReadKey();


        }

        //ejercicio 1:
        static int SumarDigitos(int numero)
        {
            int suma, digito;

            suma = 0;

            while (numero > 0)
            {
                digito = numero % 10;
                suma = suma + digito;
                numero = numero / 10;
            }

            return suma;
        
           }


    
        //ejercicio 2:
    static string ElevarAlCuadrado(ref int n)
        {
            string resultado;

            n = n * n;
            resultado = "Operación realizada correctamente";

            return resultado;
        }



        //ejercico 4:
        static double AplicarDescuento(double descuento, ref double precio)
        {
            double monto;

            monto = precio * descuento;
            precio = precio - monto;

            return monto;
        }




        //ejercicio 4:
        static int ConsumirEnergia(ref int energia)
        {
            int nuevaEnergia;

            nuevaEnergia = energia - 4;

            if (nuevaEnergia < 0)
            {
                nuevaEnergia = 0;
            }

            energia = nuevaEnergia;

            return energia;
        }

        static int RecargarEnergia(ref int energia)
        {
            int nuevaEnergia;

            nuevaEnergia = energia + 6;

            if (nuevaEnergia > 20)
            {
                nuevaEnergia = 20;
            }

            energia = nuevaEnergia;

            return energia;
        }

        static string ObtenerEstado(int energia)
        {
            string estado;

            if (energia >= 15)
            {
                estado = "Alta";
            }
            else if (energia >= 8)
            {
                estado = "Media";
            }
            else
            {
                estado = "Baja";
            }

            return estado;
        }

        static string CalcularRendimiento(int energia)
        {
            string calificacion;

            if (energia == 20)
            {
                calificacion = "S";
            }
            else if (energia >= 15)
            {
                calificacion = "A";
            }
            else if (energia >= 8)
            {
                calificacion = "B";
            }
            else
            {
                calificacion = "C";
            }

            return calificacion;
        }


    }
}
