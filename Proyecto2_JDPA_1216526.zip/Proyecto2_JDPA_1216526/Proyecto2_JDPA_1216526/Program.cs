﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto2_JDPA_1216526
{



    // CLASE PARCELA
    class Parcela
    {
        public string TipoPlanta;

        public int MesesCrecimiento;

        public int MesesNecesarios;

        public bool EstaRegada;

        public double IngresoCosecha;


        // CONSTRUCTOR
        public Parcela()
        {
            TipoPlanta = "Vacia";

            MesesCrecimiento = 0;

            MesesNecesarios = 0;

            EstaRegada = false;

            IngresoCosecha = 0;
        }
    }


    // CLASE PRINCIPAL
    class Program
    {

        // VARIABLES GLOBALES

        static Parcela[,] MatrizGranja;

        static double DineroActual;

        static double TotalIngresos = 0;

        static double TotalEgresos = 0;

        static int MesesRestantes;

        static int MesesSimulados = 0;

        static int Empleados;

        static double SueldoEmpleado;

        static int Filas;

        static int Columnas;

        static int TotalRiegos = 0;


        // CONTADORES

        static int PapasSembradas = 0;

        static int TomatesSembrados = 0;

        static int FresasSembradas = 0;

        static int PapasCosechadas = 0;

        static int TomatesCosechados = 0;

        static int FresasCosechadas = 0;

 
        // MAIN
        static void Main(string[] args)
        {
            Console.Title = "Gestion de Granja";

            Console.WriteLine("GESTION DE GRANJA");

            Console.WriteLine();

            ConfiguracionInicial();

            MatrizGranja = new Parcela[Filas, Columnas];

            for (int i = 0; i < Filas; i++)
            {
                for (int j = 0; j < Columnas; j++)
                {
                    MatrizGranja[i, j] = new Parcela();
                }
            }

            while (MesesRestantes > 0 && DineroActual > 0)
            {
                MostrarEstado();

                MostrarMenu();
            }

            Console.Clear();

            Console.WriteLine("SIMULACION FINALIZADA");

            Console.WriteLine();

            MostrarReporte();

            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Presione una tecla para salir...");

            Console.ReadKey();
        }


        // CONFIGURACION INICIAL
        static void ConfiguracionInicial()
        {
            Console.WriteLine("CONFIGURACION INICIAL");

            Console.WriteLine();

            DineroActual = LeerDoublePositivo("Ingrese el dinero inicial: Q");
            Console.WriteLine(); 

            Empleados = LeerEnteroPositivo("Ingrese el numero de empleados: ");
            Console .WriteLine();

            SueldoEmpleado = LeerDoublePositivo("Ingrese el sueldo por empleado: Q");
            Console.WriteLine();

            MesesRestantes = LeerEnteroPositivo("Ingrese los meses a simular: ");
            Console.WriteLine();

            Filas = LeerEnteroPositivo("Ingrese la cantidad de filas: ");
            Console.WriteLine();

            Columnas = LeerEnteroPositivo("Ingrese la cantidad de columnas: ");
            Console .WriteLine();


            Console.WriteLine();
            Console.WriteLine("La granja fue creada correctamente.");

            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Presione una tecla para continuar...");

            Console.ReadKey();

            Console.Clear();
        }

  
        // MOSTRAR ESTADO
        static void MostrarEstado()
        {
            Console.WriteLine("DINERO ACTUAL: Q" + DineroActual.ToString("F2"));

            Console.WriteLine("MESES RESTANTES: " + MesesRestantes);

            Console.WriteLine();

            Console.WriteLine("ESTADO DE LA GRANJA");

            Console.WriteLine();

            Console.Write("         ");

            for (int j = 0; j < Columnas; j++)
            {
                Console.Write("COL " + j + "      ");
            }

            Console.WriteLine();

            for (int i = 0; i < Filas; i++)
            {
                Console.Write("FILA " + i + "  ");

                for (int j = 0; j < Columnas; j++)
                {
                    Parcela p = MatrizGranja[i, j];

                    if (p.TipoPlanta == "Vacia")
                    {
                        Console.Write("[Vacia] ");
                    }
                    else
                    {
                        Console.Write("[" + p.TipoPlanta[0] + ":" + p.MesesCrecimiento + "/" + p.MesesNecesarios + "] ");
                    }
                }

                Console.WriteLine();
            }

            Console.WriteLine();
        }


        // MENU
        static void MostrarMenu()
        {
            Console.WriteLine("1. Sembrar");

            Console.WriteLine("2. Regar parcela");

            Console.WriteLine("3. Consultar parcela");

            Console.WriteLine("4. Avanzar mes");

            Console.WriteLine("5. Salir");

            Console.WriteLine();

            Console.Write("Seleccione una opcion: ");

            string opcion = Console.ReadLine();

            Console.Clear();

            switch (opcion)
            {
                case "1":

                    Sembrar();

                    break;

                case "2":

                    RegarParcela();

                    break;

                case "3":

                    ConsultarParcela();

                    break;

                case "4":

                    AvanzarMes();

                    break;

                case "5":

                    MesesRestantes = 0;

                    break;

                default:

                    Console.WriteLine("Opcion invalida.");

                    break;
            }

            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Presione una tecla para continuar...");

            Console.ReadKey();

            Console.Clear();
        }

 
        // OPCION SEMBRAR
        static void Sembrar()
        {
            Console.WriteLine("SEMBRAR");

            Console.WriteLine();

            int fila = LeerFila();

            int columna = LeerColumna();

            Parcela p = MatrizGranja[fila, columna];

            if (p.TipoPlanta != "Vacia")
            {
                Console.WriteLine();

                Console.WriteLine("La parcela ya tiene un cultivo.");

                return;
            }

            Console.WriteLine();

            Console.WriteLine("1. Papa");

            Console.WriteLine("2. Tomate");

            Console.WriteLine("3. Fresa");

            Console.WriteLine();

            Console.Write("Seleccione el cultivo: ");

            string opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":

                    p.TipoPlanta = "Papa";

                    p.MesesNecesarios = 2;

                    p.IngresoCosecha = 450;

                    PapasSembradas++;

                    break;

                case "2":

                    p.TipoPlanta = "Tomate";

                    p.MesesNecesarios = 3;

                    p.IngresoCosecha = 650;

                    TomatesSembrados++;

                    break;

                case "3":

                    p.TipoPlanta = "Fresa";

                    p.MesesNecesarios = 4;

                    p.IngresoCosecha = 900;

                    FresasSembradas++;

                    break;

                default:

                    Console.WriteLine();

                    Console.WriteLine("Opcion invalida.");

                    return;
            }

            p.MesesCrecimiento = 0;

            p.EstaRegada = false;

            Console.WriteLine();

            Console.WriteLine("El cultivo fue sembrado correctamente.");
        }


        // OPCION REGAR PARCELA
        static void RegarParcela()
        {
            Console.WriteLine("REGAR PARCELA");

            Console.WriteLine();

            int fila = LeerFila();

            int columna = LeerColumna();

            Parcela p = MatrizGranja[fila, columna];

            if (p.TipoPlanta == "Vacia")
            {
                Console.WriteLine();

                Console.WriteLine("La parcela esta vacia.");

                return;
            }

            if (p.EstaRegada)
            {
                Console.WriteLine();

                Console.WriteLine("La parcela ya fue regada este mes.");

                return;
            }

            if (DineroActual < 40)
            {
                Console.WriteLine();

                Console.WriteLine("No hay dinero suficiente para regar.");

                return;
            }

            DineroActual -= 40;

            TotalEgresos += 40;

            TotalRiegos++;

            p.EstaRegada = true;

            Console.WriteLine();

            Console.WriteLine("La parcela fue regada correctamente.");

            Console.WriteLine("Costo del riego: Q40");
        }


        // OPCION CONSULTAR PARCELA

        static void ConsultarParcela()
        {
            Console.WriteLine("CONSULTAR PARCELA");

            Console.WriteLine();

            int fila = LeerFila();

            int columna = LeerColumna();

            Parcela p = MatrizGranja[fila, columna];

            Console.WriteLine();

            if (p.TipoPlanta == "Vacia")
            {
                Console.WriteLine("La parcela esta vacia.");
            }
            else
            {
                Console.WriteLine("Tipo de planta: " + p.TipoPlanta);

                Console.WriteLine("Meses de crecimiento: " + p.MesesCrecimiento + "/" + p.MesesNecesarios);

                Console.WriteLine("Esta regada: " + (p.EstaRegada ? "Si" : "No"));
            }
        }

 
        // OPCION AVANZAR MES
        static void AvanzarMes()
        {
            Console.WriteLine("AVANZAR MES");

            Console.WriteLine();

            double PagoSueldos = Empleados * SueldoEmpleado;

            if (DineroActual < PagoSueldos)
            {
                PagoSueldos = DineroActual;
            }

            DineroActual -= PagoSueldos;

            TotalEgresos += PagoSueldos;

            Console.WriteLine("Sueldos pagados: Q" +
                              PagoSueldos.ToString("F2"));

            Console.WriteLine();

            for (int i = 0; i < Filas; i++)
            {
                for (int j = 0; j < Columnas; j++)
                {
                    Parcela p = MatrizGranja[i, j];

                    if (p.TipoPlanta == "Vacia")
                    {
                        continue;
                    }

                    if (p.EstaRegada)
                    {
                        p.MesesCrecimiento += 2;
                    }
                    else
                    {
                        p.MesesCrecimiento += 1;
                    }

                    Console.WriteLine("Parcela (" + i + "," + j + ")");

                    Console.WriteLine("Cultivo: " + p.TipoPlanta);

                    Console.WriteLine("Crecimiento: " + p.MesesCrecimiento + "/" + p.MesesNecesarios);

                    Console.WriteLine();

                    if (p.MesesCrecimiento >= p.MesesNecesarios)
                    {
                        DineroActual += p.IngresoCosecha;

                        TotalIngresos += p.IngresoCosecha;

                        Console.WriteLine("Cultivo cosechado.");

                        Console.WriteLine("Ganancia obtenida: Q" + p.IngresoCosecha);

                        Console.WriteLine();

                        if (p.TipoPlanta == "Papa")
                        {
                            PapasCosechadas++;
                        }

                        if (p.TipoPlanta == "Tomate")
                        {
                            TomatesCosechados++;
                        }

                        if (p.TipoPlanta == "Fresa")
                        {
                            FresasCosechadas++;
                        }

                        MatrizGranja[i, j] = new Parcela();
                    }
                    else
                    {
                        p.EstaRegada = false;
                    }
                }
            }

            MesesRestantes--;

            MesesSimulados++;

            Console.WriteLine("El mes fue completado.");

            Console.WriteLine("Meses restantes: " + MesesRestantes);
        }


        // REPORTE FINAL
        static void MostrarReporte()
        {
            int ParcelasVacias = 0;

            for (int i = 0; i < Filas; i++)
            {
                for (int j = 0; j < Columnas; j++)
                {
                    if (MatrizGranja[i, j].TipoPlanta == "Vacia")
                    {
                        ParcelasVacias++;
                    }
                }
            }

            Console.WriteLine("REPORTE FINAL");

            Console.WriteLine();

            Console.WriteLine("Dinero final: Q" +  DineroActual.ToString("F2"));

            Console.WriteLine("Total de ingresos: Q" + TotalIngresos.ToString("F2"));

            Console.WriteLine("Total de egresos: Q" + TotalEgresos.ToString("F2"));

            Console.WriteLine("Meses simulados: " + MesesSimulados);

            Console.WriteLine("Riegos realizados: " + TotalRiegos);

            Console.WriteLine("Parcelas vacias: " + ParcelasVacias);

            Console.WriteLine();

            Console.WriteLine("SIEMBRAS REALIZADAS");

            Console.WriteLine("Papas: " + PapasSembradas);

            Console.WriteLine("Tomates: " + TomatesSembrados);

            Console.WriteLine("Fresas: " + FresasSembradas);

            Console.WriteLine();

            Console.WriteLine("COSECHAS REALIZADAS");

            Console.WriteLine("Papas: " + PapasCosechadas);

            Console.WriteLine("Tomates: " + TomatesCosechados);

            Console.WriteLine("Fresas: " + FresasCosechadas);
        }


        // LEER ENTERO POSITIVO

        static int LeerEnteroPositivo(string mensaje)
        {
            int numero;

            do
            {
                Console.Write(mensaje);

                string entrada = Console.ReadLine();

                if (int.TryParse(entrada, out numero))
                {
                    if (numero > 0)
                    {
                        return numero;
                    }
                }

                Console.WriteLine();

                Console.WriteLine("Valor invalido.");

                Console.WriteLine();

            } while (true);
        }


        // LEER DOUBLE POSITIVO
        static double LeerDoublePositivo(string mensaje)
        {
            double numero;

            do
            {
                Console.Write(mensaje);

                string entrada = Console.ReadLine();

                if (double.TryParse(entrada, out numero))
                {
                    if (numero > 0)
                    {
                        return numero;
                    }
                }

                Console.WriteLine();

                Console.WriteLine("Valor invalido.");

                Console.WriteLine();

            } while (true);
        }

 
        // LEER FILA
        static int LeerFila()
        {
            int fila;

            do
            {
                Console.Write("Ingrese la fila: ");

                string entrada = Console.ReadLine();

                if (int.TryParse(entrada, out fila))
                {
                    if (fila >= 0 && fila < Filas)
                    {
                        return fila;
                    }
                }

                Console.WriteLine();

                Console.WriteLine("Fila invalida.");

                Console.WriteLine();

            } while (true);
        }


        // LEER COLUMNA
        static int LeerColumna()
        {
            int columna;

            do
            {
                Console.Write("Ingrese la columna: ");

                string entrada = Console.ReadLine();

                if (int.TryParse(entrada, out columna))
                {
                    if (columna >= 0 && columna < Columnas)
                    {
                        return columna;
                    }
                }

                Console.WriteLine();

                Console.WriteLine("Columna invalida.");

                Console.WriteLine();

            } while (true);
        }
    }
}