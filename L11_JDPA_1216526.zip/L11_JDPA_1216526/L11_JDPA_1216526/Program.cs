﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;

namespace L11_JDPA_1216526
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese su nombre: ");
            string nombre = Console.ReadLine();
            Console.WriteLine("Bienvenido(a), " + nombre);

            //ejercicio 1: 
            Console.WriteLine();
            Console.WriteLine("Ejercicio 1: ");
            

            string contraseña;
            int i;
            bool Mayusculas = false, Numero = false, Caracter = false;

            do {
                Console.WriteLine();
                Console.WriteLine("Ingrese su contraseña: ");
                contraseña = Console.ReadLine();

                for (i = 0; i < contraseña.Length; i++)
                {
                    if (char.IsUpper(contraseña[i]))
                    {
                        Mayusculas = true;
                    }
                    else if (char.IsDigit(contraseña[i]))
                    {
                        Numero = true;
                    }
                    else if (!char.IsLetterOrDigit(contraseña[i]))
                    {
                        Caracter = true;
                    }
                }

                if (Mayusculas == false)
                {
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Contraseña inválida. Debe contener al menos una letra mayúscula");
                    Console.ResetColor();

                }

                if (Numero == false)
                {
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Contraseña inválida. Debe contener al menos un Numero");
                    Console.ResetColor();
                }


                if (Caracter == false)
                {
                    Console.WriteLine();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Contraseña inválida. Debe contener al menos un caracter especial");
                    Console.ResetColor();

                }

                if (contraseña.Length < 8)
                {
                    {
                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("Contraseña inválida. Debe contener al menos 8 caracteres");
                        Console.ResetColor();
                    }
                }
            } while (Mayusculas == false || Numero == false || Caracter == false || contraseña.Length < 8);

            if (Mayusculas && Numero && Caracter == true)
            {
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Contraseña válida.");
                Console.ResetColor();
            }


            Console.WriteLine();
                Console.WriteLine();
                Console.WriteLine("Ingrese una tecla para continuar...");
                Console.ReadKey();
                Console.Clear();


                //ejercicio 2:  
                Console.WriteLine("Ejercicio 2: ");
                Console.WriteLine();

                int i2;
                string texto, invertido = "";   

                Console.Write("Ingrese un texto: ");
                texto = Console.ReadLine();

                for ( i2 = texto.Length - 1;i2 >= 0; i2--)
                {
                    invertido += texto[i2]; 
                }

                Console.WriteLine();
                Console.WriteLine("el texto invertido es: " + invertido);

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Ingrese una tecla para continuar...");
            Console.ReadKey();
            Console.Clear();




            //ejercicio 3: 
                Console.WriteLine("Ejercicio 3: ");
                Console.WriteLine();

            int i3, cantidad, suma = 0;
            double promedio;

            Console.Write("Ingrese la cantidad de números que desea ingresar: ");
            cantidad = int.Parse(Console.ReadLine());

            int[] numeros = new int[cantidad];

            
            for (i3 = 0; i3 < cantidad; i3++)
            {
                Console.WriteLine();
                Console.Write("Ingrese el número " + (i3 + 1) + ": ");
                numeros[i3] = int.Parse(Console.ReadLine());
            }

            
            int menor = numeros[0];
            int mayor = numeros[0];

            
            for (i3 = 0; i3 < cantidad; i3++)
            {
                suma += numeros[i3];

                if (numeros[i3] < menor)
                    menor = numeros[i3];

                if (numeros[i3] > mayor)
                    mayor = numeros[i3];
            }


            promedio = suma / cantidad;

            Console.WriteLine();
            Console.WriteLine("Suma = " + suma);
            Console.WriteLine("Promedio = " + promedio);
            Console.WriteLine("Menor = " + menor);
            Console.WriteLine("Mayor = " + mayor);


            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Ingrese una tecla para continuar...");
            Console.ReadKey();
            Console.Clear();


            //ejercicio 4
            Console.WriteLine("Ejercicio 4: ");
            Console.WriteLine();

            int i4, buscar, posicion = -1;

            int[] numeros4 = new int[8];

            
            for (i4 = 0; i4 < 8; i4++)
            {
                Console.Write("Ingrese el número " + (i4 + 1) + ": ");
                numeros4[i4] = int.Parse(Console.ReadLine());
            }

            Console.WriteLine();
            Console.Write("Ingrese el número a buscar: ");
            buscar = int.Parse(Console.ReadLine());

           
            for (i4  = 0; i4 < 8; i4++)
            {
                if (numeros4[i4] == buscar)
                {
                    posicion = i4;
                    break; 
                }
            }

            Console.WriteLine();

           
            if (posicion != -1)
            {
                Console.WriteLine("El número sí existe en la posición " + posicion);
            }
            else
            {
                Console.WriteLine("El número no existe en el arreglo");
            }


            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Ingrese una tecla para continuar...");
            Console.ReadKey();
            Console.Clear();




            // ejercicio 5
            Console.WriteLine("Ejercicio 5: ");
            Console.WriteLine();


            int i5, contador = 0;
            string[] nombres = new string[5];
            string nombreMasLargo;

            
            for (i5 = 0; i5 < 5; i5++)
            {
                Console.Write("Ingrese el nombre " + (i5 + 1) + ": ");
                nombres[i5] = Console.ReadLine();
            }

            nombreMasLargo = nombres[0];

            for (i5 = 0; i5 < 5; i5++)
            {
                if (nombres[i5].Length > 5)
                    contador++;

                if (nombres[i5].Length > nombreMasLargo.Length)
                    nombreMasLargo = nombres[i5];
            }

            Console.WriteLine();

           
            Console.Write("Nombres ingresados: ");
            for (i5 = 0; i5 < 5; i5++)
            {
                Console.Write(nombres[i5]);

                if (i5 < 4)
                    Console.Write(", ");
            }

            Console.WriteLine();
            Console.WriteLine("Más de 5 letras: " + contador);
            Console.WriteLine("Nombre más largo: " + nombreMasLargo);



            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Ingrese una tecla para salir...");
            Console.ReadKey();
            Console.Clear();






        }
    }
}

