﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L6_JDPA_1216526
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Ejercicio 1 

           int transporte;

            Console.WriteLine("Ejercicio 1:");
            Console.WriteLine();
            
            Console.WriteLine("Ingrese el medio de transporte (1 = Bicicleta, 2 = Motocicleta, 3 = Auto, 4 = Camion, 5 = Autobus): ");
            transporte = int.Parse(Console.ReadLine());

            switch (transporte) {

                case 1:
                    Console.WriteLine();
                    Console.WriteLine("Vehiculo no motorizado");
                    break;

                case 2:
                    Console.WriteLine();
                    Console.WriteLine("Vehiculo ligero");
                    break;



                case 3:
                    Console.WriteLine();
                    Console.WriteLine("Vehiculo mediano");
                    break;


                case 4:
                    Console.WriteLine();
                    Console.WriteLine("Vehiculo pesado");
                    break;


                case 5:
                    Console.WriteLine();
                    Console.WriteLine("Vehiculo publico");
                    break;



                default:
                    Console.WriteLine();
                    Console.WriteLine("Opcion no valida");
                    break;

            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("INGRESE UNA TECLA PARA CONTINUAR...");
            Console.ReadKey();
            Console.Clear();


            //ejercicio 2 

            Console.WriteLine("Ejercicio 2:");
            Console.WriteLine();

            int tarjeta;
            double limite, limite_total;

            Console.Write("Ingrese el tipo de tarjeta del cliente: ");
            tarjeta = int.Parse(Console.ReadLine());

            Console.WriteLine();
            Console.Write("Ingrese el limite de su tarjeta: ");
            limite  = Convert.ToDouble(Console.ReadLine());

            switch (tarjeta)
            {
                case 1:
                    limite_total = limite * (0.25 + 1);
                    Console.WriteLine();
                    Console.WriteLine("Su nuevo limite es de: " + limite_total);
                    break;

                case 2:
                    limite_total = limite * (0.35 + 1);
                    Console.WriteLine();
                    Console.WriteLine("su nuevo limite es de: " + limite_total);
                    break;

                case 3:
                    limite_total = limite * (0.40 + 1);
                    Console.WriteLine();
                    Console.WriteLine("su nuevo limite es de: " + limite_total);
                    break;

                default:
                    limite_total = limite * (0.50 + 1);
                    Console.WriteLine();
                    Console.WriteLine("su nuevo limite es de: " + limite_total);
                    break;

            }



            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("INGRESE UNA TECLA PARA CONTINUAR...");
            Console.ReadKey();
            Console.Clear();




            //Ejercicio 3: 
            Console.WriteLine("Ejercicio 3:");
            Console.WriteLine();

            double evaluacion, pago_total, caso;

            Console.WriteLine("Ingrese el resultado de la evaluacion de el empleado (solo se puede ingresar 0.0, 0.4 o 0,6 y mas): ");
            evaluacion = Convert.ToDouble(Console.ReadLine());


            caso = 0;

            if(evaluacion == 0.0)
            {
                caso = 1;
            }

            if (evaluacion == 0.4)
            {
                caso = 2;
            }

            if(evaluacion >= 0.6)
            {
                caso = 3;
            }

            switch (caso)
            {
                case 1:
                    pago_total = evaluacion * 2400;
                    Console.WriteLine();
                    Console.WriteLine("Su pago final es de: " + pago_total);
                    break;


                case 2:
                    pago_total = evaluacion * 2400;
                    Console.WriteLine();
                    Console.WriteLine("Su pago final es de: " + pago_total);
                    break;


                case 3:
                    pago_total =  evaluacion * 2400;
                    Console.WriteLine();
                    Console.WriteLine("Su pago final es de: " + pago_total);
                    break;

            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("INGRESE UNA TECLA PARA CONTINUAR...");
            Console.ReadKey();
            Console.Clear();


            //Ejercicio 4

            Console.WriteLine("Ejercicio 4:");
            Console.WriteLine();
            int pizza;
            string ingrediente;

            Console.WriteLine("Que pizza desea ordenar (1 = vegetariana / 0 = no vegetariana): ");
            pizza = int.Parse(Console.ReadLine());

            switch(pizza){
                 
                case 1:
                    Console.WriteLine();
                    Console.WriteLine("Ingredientes: Pimiento y tofu");
                    Console.Write("elija una opcion: ");
                    ingrediente = Console.ReadLine();
                    Console.WriteLine();
                    Console.WriteLine("La pizza elejida es vegetariana");
                    Console.WriteLine();
                    Console.WriteLine("La lista de sus ingredientes es: Tomate, mozzarella y " + ingrediente);
                    break;


                case 2:
                    Console.WriteLine();
                    Console.WriteLine("Ingredites: peperoni, jamon y salmon");
                    Console.Write("elija una opcion :");
                    ingrediente = Console.ReadLine();
                    Console.WriteLine();
                    Console.WriteLine("La pizza elejida es no vegetariana");
                    Console.WriteLine();
                    Console.WriteLine("La lista de sus ingredientes es: Tomate, mozzarella y  " + ingrediente);
                    break;

                default: 
                    Console.WriteLine();
                    Console.WriteLine("Opcion no valida");
                    break;

            }

            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("INGRESE UNA TECLA PARA CONTINUAR...");
            Console.ReadKey();



        }
    }
}
