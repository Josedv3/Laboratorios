﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace L4___JDPA_1216526
{
    internal class Program
    {
        static void Main(string[] args)
        {


            // Entrada de usuario
            Console.Write("¿Cómo te llamas? ");
            string nombre = Console.ReadLine();
            // Salida de datos

            Console.WriteLine("Hola, " + nombre + " ¡Bienvenido a C#!");

            // Ejercicio 1:
            Console.WriteLine("Registro de Nave Espacial:");

            string modelo_nave;
            int capacidad = 200;
            float combustible;
            bool salto;



            Console.WriteLine();
            Console.WriteLine("modelo de la nave: ");
            modelo_nave = Console.ReadLine();


            Console.WriteLine();
            Console.WriteLine("nivel de combustible: ");
            combustible = float.Parse(Console.ReadLine());

            Console.WriteLine();

            Console.WriteLine("Motor de salto activo? (true/false): ");
            salto = bool.Parse(Console.ReadLine());

            Console.WriteLine("La nave modelo: " + modelo_nave + " , con capacidad de: " + capacidad + "kg, Tiene un nivel de combustible de: " + combustible);
            Console.WriteLine("Estado de Motor de salto: " + salto);
            Console.WriteLine();
            Console.WriteLine("Ingrese una tecla para continuar");

            Console.ReadKey();

            Console.Clear();

            // Ejercicio 2

            Console.WriteLine("Expansion de Memoria:");
            Console.WriteLine();

            short sensores_activos = 128, registro_procesador, Precisiom_Total;


            Console.WriteLine("Sensores Activos = " + sensores_activos);

            registro_procesador = Convert.ToInt16(sensores_activos);
            Console.WriteLine("..... Registro procesador  = " + registro_procesador);

            Precisiom_Total = Convert.ToInt16(registro_procesador);
            Console.WriteLine(".............. Precision total = " + Precisiom_Total);

            Console.WriteLine();
            Console.WriteLine("La precision total es de = " + Precisiom_Total);

            Console.WriteLine();
            Console.WriteLine("Presione una tecla para continuar");

            Console.ReadKey();
            Console.Clear();


            //Ejercicio 3
            Console.WriteLine("Ajuste de Energia:");
            Console.WriteLine();

            double Energia_Generada = 987.65;
            int Energia_Limitada;


            Energia_Limitada = Convert.ToInt16(Energia_Generada);

            Console.WriteLine("Energia Generada: " + Energia_Generada);
            Console.WriteLine();
            Console.WriteLine("Energia Limitada: " + Energia_Limitada);

            Console.WriteLine();
            Console.WriteLine("Presione una tecla para continuar");

            Console.ReadKey();
            Console.Clear();

            // Ejercicio 4

            Console.WriteLine("Recepción de Coordenadas:");

            Console.WriteLine();

            string Entrada_Radar;
            int Entrada_Radar1, margen_de_seguridad;


            Console.WriteLine("Ingrese la distancia del planeta mas cercano (solo numeros): ");
            Entrada_Radar = Console.ReadLine();


            Entrada_Radar1 = int.Parse(Entrada_Radar);

            margen_de_seguridad = Entrada_Radar1 + 100;

            Console.WriteLine();
            Console.WriteLine("La distancia del planeta mas cercano con margen de seguridad es de: " + margen_de_seguridad + " km");

            Console.WriteLine();
            Console.WriteLine("Ingrese una tecla para continuar");

            Console.ReadKey();
            Console.Clear();

            // Ejercicio 5

            Console.WriteLine("Panel de Control:");
            Console.WriteLine();

            string señal_de_oxigeno = "true", temp = "22.8";
            bool señal_final;
            double temp_cabina;


            señal_final = Convert.ToBoolean(señal_de_oxigeno);

            temp_cabina = Convert.ToDouble(temp);

            Console.WriteLine("La señal de oxigeno en la cabina es: " + señal_final);
            Console.WriteLine();
            Console.WriteLine("La temperatura en cabina es: " + temp_cabina + " grados");

            Console.WriteLine();
            Console.WriteLine("Ingrese una tecla para continuar");

            Console.ReadKey();
            Console.Clear();


            // Ejercicio 6
            Console.WriteLine("Reporte de Mision");
            Console.WriteLine();

            double VelocidadLuz = 299792.458;
            string Velocidad_Texto;

            Velocidad_Texto = VelocidadLuz.ToString("N3");

            Console.WriteLine(Velocidad_Texto);

            Console.WriteLine();
            Console.WriteLine("Ingrese una tecla para continuar");

            Console.ReadKey();
            Console.Clear();


            // Ejercicio 7

            Console.WriteLine("Calculadora de Suministros");
            Console.WriteLine();

            string precio;
            double precio_galon, impuesto_galactico, costo_total;
            int precio_final;

            Console.Write("Ingrese el precio por galon de litio: Q");
            precio = Console.ReadLine();
            Console.WriteLine();

            precio_galon = Convert.ToDouble(precio);

            impuesto_galactico = precio_galon * 0.12;
            Console.WriteLine("El impuesto galactico es de: Q" + impuesto_galactico);


            costo_total = precio_galon + impuesto_galactico;

            precio_final = Convert.ToInt16(costo_total);

            Console.WriteLine();
            Console.Write("El costo final del suministro es de: Q" + precio_final);

            Console.WriteLine();
            Console.WriteLine("Presione una tecla para salir");
            Console.ReadKey();


        
        }
    }
}
